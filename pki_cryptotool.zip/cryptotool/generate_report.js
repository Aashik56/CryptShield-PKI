const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  LevelFormat, PageNumber, Header, Footer
} = require('docx');
const fs = require('fs');

const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };
const headerBorder = { style: BorderStyle.SINGLE, size: 1, color: "1F4E79" };
const headerBorders = { top: headerBorder, bottom: headerBorder, left: headerBorder, right: headerBorder };

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 320, after: 160 },
    children: [new TextRun({ text, bold: true, size: 32, color: "1F4E79", font: "Arial" })]
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120 },
    children: [new TextRun({ text, bold: true, size: 26, color: "2E74B5", font: "Arial" })]
  });
}
function body(text, opts = {}) {
  return new Paragraph({
    spacing: { before: 100, after: 100 },
    children: [new TextRun({ text, size: 22, font: "Arial", ...opts })]
  });
}
function bullet(text) {
  return new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    spacing: { before: 60, after: 60 },
    children: [new TextRun({ text, size: 22, font: "Arial" })]
  });
}
function codeBlock(text) {
  return new Paragraph({
    spacing: { before: 60, after: 60 },
    shading: { fill: "F0F0F0", type: ShadingType.CLEAR },
    indent: { left: 360 },
    children: [new TextRun({ text, size: 18, font: "Courier New", color: "333333" })]
  });
}
function spacer() {
  return new Paragraph({ children: [new TextRun("")], spacing: { before: 80, after: 80 } });
}

function makeTable(headers, rows, colWidths) {
  const total = colWidths.reduce((a, b) => a + b, 0);
  return new Table({
    width: { size: total, type: WidthType.DXA },
    columnWidths: colWidths,
    rows: [
      new TableRow({
        tableHeader: true,
        children: headers.map((h, i) => new TableCell({
          borders: headerBorders,
          width: { size: colWidths[i], type: WidthType.DXA },
          shading: { fill: "1F4E79", type: ShadingType.CLEAR },
          margins: { top: 80, bottom: 80, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, color: "FFFFFF", size: 20, font: "Arial" })] })]
        }))
      }),
      ...rows.map((row, ri) => new TableRow({
        children: row.map((cell, ci) => new TableCell({
          borders,
          width: { size: colWidths[ci], type: WidthType.DXA },
          shading: { fill: ri % 2 === 0 ? "EBF3FB" : "FFFFFF", type: ShadingType.CLEAR },
          margins: { top: 60, bottom: 60, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: cell, size: 20, font: "Arial" })] })]
        }))
      }))
    ]
  });
}

const doc = new Document({
  numbering: {
    config: [
      {
        reference: "bullets",
        levels: [{
          level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: 720, hanging: 360 } } }
        }]
      }
    ]
  },
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
  },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 },
        margin: { top: 1440, right: 1260, bottom: 1440, left: 1260 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: "ST6051CEM | PKI Cryptographic Tool Report", size: 18, color: "666666", font: "Arial" })]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "Page ", size: 18, color: "666666" }), new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "666666" })]
        })]
      })
    },
    children: [
      // ── TITLE PAGE ──
      spacer(), spacer(), spacer(),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 200, after: 100 },
        children: [new TextRun({ text: "PKI Cryptographic Tool Development", bold: true, size: 52, color: "1F4E79", font: "Arial" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 80, after: 80 },
        children: [new TextRun({ text: "Open-Source Cryptographic Tool Development", size: 28, color: "2E74B5", font: "Arial" })]
      }),
      spacer(),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: "Module: ST6051CEM — Practical Cryptography", size: 22, font: "Arial", color: "444444" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: "Softwarica College of IT & E-Commerce | Coventry University", size: 22, font: "Arial", color: "444444" })]
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: "Submission Date: 5th March 2026", size: 22, font: "Arial", color: "444444" })]
      }),
      spacer(), spacer(), spacer(),

      // ── 1. INTRODUCTION ──
      h1("1. Introduction"),
      body("Cryptographic systems are fundamental to modern digital security. This report describes the design, development, and security analysis of a Python-based open-source PKI (Public Key Infrastructure) cryptographic tool built to address real-world security problems. The tool provides key generation and certificate management, digital signatures, hybrid encryption, and defences against common attacks such as replay attacks, man-in-the-middle (MITM) attacks, and unauthorised signature forgery."),
      spacer(),
      body("The tool is implemented entirely using the Python cryptography library — a well-audited, production-grade library — and exposes a clean command-line interface for all operations. All source code is open-source and hosted on GitHub with full documentation."),
      spacer(),

      // ── 2. CRYPTOGRAPHIC TECHNIQUES ──
      h1("2. Cryptographic Techniques and Algorithms"),

      h2("2.1 RSA-2048 Key Generation"),
      body("The tool generates RSA-2048 asymmetric key pairs for each identity using a public exponent of 65537 (the standard Fermat prime F4). RSA-2048 is widely considered secure for at least the next decade and is the baseline recommended by NIST SP 800-131A."),
      spacer(),
      body("Each key pair is accompanied by a self-signed X.509 certificate, which binds the identity's name to their public key. This mirrors real-world PKI certificate workflows. Certificates are given a one-year validity period and include a BasicConstraints extension marking them as end-entity (not CA) certificates."),
      spacer(),

      h2("2.2 RSA-PSS Digital Signatures"),
      body("Digital signatures use RSA-PSS (Probabilistic Signature Scheme) with SHA-256 as the hash function. RSA-PSS is the modern replacement for PKCS#1 v1.5 signatures and provides provable security under the random oracle model. Key advantages of RSA-PSS include:"),
      bullet("Probabilistic output: signing the same message twice produces different signatures, preventing certain oracle attacks."),
      bullet("Salt randomisation: each signature includes a random salt, improving security against precomputation attacks."),
      bullet("Tight security reduction: RSA-PSS security is tightly tied to the hardness of the RSA problem."),
      spacer(),
      body("Each signed file produces both a binary .sig file (the raw RSA-PSS signature) and a JSON metadata file containing the signer identity, SHA-256 file hash, ISO timestamp, and a random 128-bit nonce for replay attack prevention."),
      spacer(),

      h2("2.3 Hybrid Encryption (RSA-OAEP + AES-256-GCM)"),
      body("File and message encryption uses a hybrid scheme — the industry-standard approach used in TLS, PGP, and S/MIME:"),
      spacer(),
      makeTable(
        ["Layer", "Algorithm", "Purpose"],
        [
          ["Key Encapsulation", "RSA-OAEP + SHA-256", "Encrypt the session key for the recipient"],
          ["Data Encryption", "AES-256-GCM", "Encrypt the actual file/message content"],
          ["Integrity", "GCM Auth Tag (128-bit)", "Detect any ciphertext tampering"]
        ],
        [2800, 3000, 3226]
      ),
      spacer(),
      body("A fresh 256-bit AES key and 96-bit GCM nonce are generated for every encryption operation, ensuring that no two encryptions — even of the same plaintext — produce the same ciphertext (IND-CPA security). The GCM authentication tag is embedded in the ciphertext and verified on decryption, providing authenticated encryption (AEAD)."),
      spacer(),

      h2("2.4 PKCS#12 Secure Key Storage"),
      body("Private keys can be exported to PKCS#12 (.p12) password-protected keystores. This simulates HSM (Hardware Security Module) style key protection, where private keys are never stored in plaintext but are always protected by a strong passphrase. PKCS#12 is the standard format used by browsers, Java keystores, and enterprise PKI systems."),
      spacer(),

      h2("2.5 Certificate Revocation"),
      body("The tool maintains a local Certificate Revocation List (CRL) as a JSON file. When a certificate is revoked, its X.509 serial number is recorded with a timestamp. All signature verification and other operations first check the CRL before proceeding. This prevents an attacker who has obtained a private key from using it even if the certificate was previously trusted."),
      spacer(),

      // ── 3. SECURITY FEATURES ──
      h1("3. Security Features and Threat Protection"),

      h2("3.1 Man-in-the-Middle (MITM) Attack Prevention"),
      body("MITM attacks are prevented through public-key certificate binding. Each identity's public key is embedded in an X.509 certificate, and signature verification always loads the public key from the certificate tied to the claimed signer identity. An attacker who intercepts a signed file cannot substitute their own public key without also possessing the legitimate signer's private key."),
      spacer(),
      body("Additionally, since signatures include SHA-256 hashes of the signed content, any modification to the file in transit is detected immediately during verification — the hash mismatch causes the verification to fail before the cryptographic signature is even checked."),
      spacer(),

      h2("3.2 Replay Attack Prevention"),
      body("Replay attacks occur when an attacker captures a valid signed message and re-submits it later (e.g., re-sending an authorisation). The tool prevents replay attacks using two complementary mechanisms:"),
      bullet("Timestamp window: each signature includes an ISO 8601 UTC timestamp. Signatures older than 60 minutes are automatically rejected."),
      bullet("Nonce tracking: each signature includes a 128-bit random nonce. The verifier records used nonces in a persistent store. If the same nonce appears in a second verification, the request is immediately rejected as a replay attack."),
      spacer(),
      body("The test suite includes a dedicated replay attack test that confirms the first verification succeeds while the second (replay) is correctly rejected."),
      spacer(),

      h2("3.3 Signature Forgery Prevention"),
      body("Signature forgery is prevented cryptographically — an attacker (Mallory) who signs a document with their own private key and then changes the metadata to claim the signature was from Alice will fail verification, because Alice's public key cannot verify a signature produced by Mallory's private key. This is formally guaranteed by the security of RSA-PSS."),
      spacer(),

      h2("3.4 Tamper Detection"),
      body("Two independent layers of tamper detection are implemented:"),
      bullet("SHA-256 hash check: the file's hash at signing time is stored in metadata. On verification, the current hash is compared. Any byte-level change to the file is detected."),
      bullet("AES-GCM authentication tag: for encrypted files, the 128-bit GCM tag authenticates the ciphertext. Any modification to the encrypted bytes causes decryption to throw an InvalidTag exception, protecting against chosen-ciphertext attacks."),
      spacer(),

      h2("3.5 Forward Secrecy (Ephemeral Session Keys)"),
      body("Each encryption operation generates a fresh random AES-256 session key. This provides forward secrecy at rest — if an attacker later compromises the recipient's RSA private key, they cannot decrypt previously captured ciphertexts because each session key was unique, ephemeral, and is no longer available."),
      spacer(),

      h2("3.6 Security Summary Table"),
      makeTable(
        ["Threat", "Mitigation", "Implementation"],
        [
          ["MITM / Key Substitution", "X.509 certificate binding", "keygen.py + verify.py CRL check"],
          ["File Tampering", "SHA-256 + GCM auth tag", "sign.py + verify.py + decrypt.py"],
          ["Replay Attacks", "Nonce store + timestamp window", "verify.py _check_nonce()"],
          ["Signature Forgery", "RSA-PSS cryptographic binding", "sign.py + verify.py"],
          ["Unauthorised Decryption", "RSA-OAEP key encapsulation", "encrypt.py + decrypt.py"],
          ["Key Compromise", "Certificate revocation (CRL)", "keygen.py + verify.py"],
          ["Weak Key Storage", "PKCS#12 password-protected", "keygen.py export_pkcs12()"]
        ],
        [2400, 2600, 3026]
      ),
      spacer(),

      // ── 4. USE CASES ──
      h1("4. Use Case Demonstrations"),

      h2("Use Case 1: Legal Document Signing"),
      body("Problem: A legal firm needs to sign contracts electronically and allow clients to verify authenticity. Email attachments can be tampered with in transit. Without cryptographic signatures, there is no way to detect tampering or prove who signed."),
      spacer(),
      body("Solution: Alice (the lawyer) generates an RSA-2048 key pair and X.509 certificate. She uses the tool to sign a contract PDF. The signed metadata file and binary signature are sent alongside the document. Bob (the client) uses Alice's public key to verify the signature and confirms the file's SHA-256 hash matches. Any modification to the contract — even a single character — causes verification to fail. Certificate revocation ensures that if Alice's firm is compromised, previously issued certificates can be revoked."),
      spacer(),
      body("Cryptographic features used: RSA-2048 key generation, X.509 certificate, RSA-PSS signature, SHA-256 integrity check, certificate revocation check."),
      spacer(),

      h2("Use Case 2: Secure Messaging Between Parties"),
      body("Problem: Two developers working remotely need to exchange sensitive API keys and credentials. Plain email is insecure — credentials sent over email can be intercepted, and email servers themselves may be compromised."),
      spacer(),
      body("Solution: Alice encrypts the credentials using Bob's RSA public key via the hybrid RSA-OAEP + AES-256-GCM scheme. Even if Eve intercepts the ciphertext, she cannot decrypt it without Bob's private key. The GCM authentication tag ensures the ciphertext cannot be modified in transit without detection. Bob decrypts the message using his private key and receives the original credentials. Each encryption uses a fresh session key, providing forward secrecy."),
      spacer(),
      body("Cryptographic features used: RSA-OAEP key encapsulation, AES-256-GCM authenticated encryption, ephemeral session keys."),
      spacer(),

      h2("Use Case 3: Software Release Integrity Verification"),
      body("Problem: A software company distributes binary releases on the internet. Without integrity verification, users cannot distinguish authentic releases from malware-injected fakes. Supply chain attacks have become increasingly common."),
      spacer(),
      body("Solution: The company generates an RSA-2048 key pair. Before publishing each release, the binary is signed using the tool. The signature metadata and the company's public certificate are published alongside the binary. Users run the verify command before installing — if the binary has been tampered with, replaced, or if the company's certificate has been revoked (e.g., following a key compromise), the verification fails and installation is aborted. Replay attack prevention ensures old signatures for previous versions cannot be reused for new releases."),
      spacer(),
      body("Cryptographic features used: RSA-PSS signing, SHA-256 file integrity, certificate validation, revocation checking, replay prevention."),
      spacer(),

      // ── 5. CODE QUALITY ──
      h1("5. Code Quality and Open-Source Practices"),

      h2("5.1 Modular Architecture"),
      body("The codebase is split into five focused modules, each with a single responsibility:"),
      bullet("keygen.py — key generation, certificate management, revocation"),
      bullet("sign.py — digital signature creation"),
      bullet("verify.py — signature verification with attack prevention"),
      bullet("encrypt.py — hybrid encryption"),
      bullet("decrypt.py — hybrid decryption"),
      bullet("main.py — CLI interface wiring all modules together"),
      spacer(),
      body("This separation of concerns makes each module independently testable and allows the community to extend individual components without modifying others."),
      spacer(),

      h2("5.2 Documentation"),
      body("Every module begins with a docstring explaining its purpose and the security properties it provides. Every function has a complete docstring with argument descriptions and return values. The README.md provides installation instructions, quick-start examples, file structure overview, and security design rationale."),
      spacer(),

      h2("5.3 Testing"),
      body("The test suite (tests/test_cryptotool.py) contains 18 unit and integration tests using Python's standard unittest framework. Tests are grouped into four classes:"),
      bullet("TestKeyGeneration — covers key pair creation, PKCS#12 export, certificate validation, and revocation."),
      bullet("TestDigitalSignatures — covers valid signatures, tampered files, forgery attempts, revoked certificate rejection, and replay attacks."),
      bullet("TestEncryptionDecryption — covers roundtrip correctness, wrong-recipient rejection, tampered ciphertext detection, and IND-CPA compliance."),
      bullet("TestMultiUserWorkflow — end-to-end multi-user scenario with Alice, Bob, Charlie, and Mallory."),
      spacer(),
      body("All 18 tests pass with zero failures."),
      spacer(),

      h2("5.4 Open-Source Contribution Guidelines"),
      body("The repository includes an MIT licence making it freely usable and modifiable. Community contributors can extend the tool by: adding ECC (elliptic curve) key support, implementing OCSP (Online Certificate Status Protocol) for real-time revocation, adding a GUI frontend, or integrating with existing email clients for S/MIME-style signing. The modular design makes all these extensions straightforward."),
      spacer(),

      // ── 6. CHALLENGES ──
      h1("6. Implementation Challenges and Reflections"),

      h2("6.1 File Format Design for Hybrid Encryption"),
      body("One challenge was designing a compact, self-contained binary file format for encrypted files. The format needed to store: the RSA-encrypted AES key (variable length, depends on RSA key size), the AES-GCM nonce (12 bytes), and the ciphertext with embedded auth tag. The solution was a simple length-prefixed format — the first 4 bytes encode the length of the encrypted key, allowing the reader to correctly extract all subsequent fields without external metadata."),
      spacer(),

      h2("6.2 Replay Attack Prevention Across Sessions"),
      body("Preventing replay attacks requires persistent state — used nonces must be remembered across process restarts. A simple in-memory set would lose this state on exit. The solution was a JSON file (used_nonces.json) that persists nonces between runs. A production system would use a database or cache (e.g., Redis) with appropriate TTL settings, but the JSON approach is sufficient for demonstration and can be easily replaced."),
      spacer(),

      h2("6.3 datetime.utcnow() Deprecation"),
      body("During development, the cryptography library emitted deprecation warnings about datetime.utcnow() in Python 3.12+. While this does not affect functionality, a future improvement would be to replace all datetime.utcnow() calls with timezone-aware equivalents using datetime.now(datetime.UTC), ensuring forward compatibility with Python 3.14 when utcnow() is scheduled for removal."),
      spacer(),

      h2("6.4 Potential Improvements"),
      bullet("ECC (ECDSA / ECDH) support: elliptic curve algorithms offer equivalent security to RSA with much smaller key sizes, improving performance for resource-constrained environments."),
      bullet("OCSP integration: replace the local JSON CRL with an OCSP responder for real-time certificate status checking."),
      bullet("Certificate chain validation: support intermediate CA certificates for a full multi-level PKI hierarchy."),
      bullet("GUI frontend: a browser-based or desktop GUI would make the tool accessible to non-technical users."),
      bullet("Hardware key storage: integration with smartcard APIs or platform key stores (e.g., Windows CNG, macOS Keychain) for production-grade private key protection."),
      spacer(),

      // ── 7. LINKS ──
      h1("7. Project Links"),
      body("GitHub Repository: https://github.com/yourusername/pki-cryptotool", { bold: true }),
      body("(Replace with your actual GitHub username before submission)"),
      spacer(),
      body("Video Demonstration: [Insert YouTube/SharePoint link to your screen-recorded demo here]", { bold: true }),
      spacer(),
      body("The video demonstration covers: key generation, file signing, signature verification, tampered file rejection, hybrid encryption/decryption, replay attack simulation, and certificate revocation."),
      spacer(),

      // ── 8. REFERENCES ──
      h1("8. References"),
      body("Barker, E. (2020). Recommendation for Key Management — Part 1: General. NIST Special Publication 800-57. National Institute of Standards and Technology."),
      spacer(),
      body("Bellare, M., & Rogaway, P. (1996). The exact security of digital signatures — How to sign with RSA and Rabin. EUROCRYPT 1996."),
      spacer(),
      body("Cooper, D. et al. (2008). Internet X.509 Public Key Infrastructure Certificate and CRL Profile. RFC 5280. IETF."),
      spacer(),
      body("Jonsson, J., & Kaliski, B. (2003). Public-Key Cryptography Standards (PKCS) #1: RSA Cryptography Specifications Version 2.1. RFC 3447. IETF."),
      spacer(),
      body("McGrew, D., & Viega, J. (2004). The Galois/Counter Mode of Operation (GCM). NIST Submission."),
      spacer(),
      body("Python Cryptography Authority. (2024). cryptography — Cryptographic Recipes and Primitives. https://cryptography.io"),
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('/home/claude/cryptotool/report.docx', buffer);
  console.log('Report created: report.docx');
});
