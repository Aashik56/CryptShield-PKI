# -*- coding: utf-8 -*-
"""
main.py - Command Line Interface
PKI Cryptographic Tool | ST6051CEM Coursework

Usage examples:
  python main.py keygen alice
  python main.py sign alice document.pdf
  python main.py verify signatures/document.pdf_alice.meta.json
  python main.py encrypt bob secret.txt
  python main.py decrypt bob secret.txt.enc
  python main.py revoke alice
  python main.py validate alice
  python main.py pkcs12 alice MyPassword
  python main.py demo
"""

import sys
import argparse


def cmd_keygen(args):
    from keygen import generate_rsa_keypair
    generate_rsa_keypair(args.identity)


def cmd_sign(args):
    from sign import sign_file
    sign_file(args.identity, args.file)


def cmd_verify(args):
    from verify import verify_file
    ok = verify_file(args.meta, skip_replay_check=args.no_replay)
    sys.exit(0 if ok else 1)


def cmd_encrypt(args):
    from encrypt import encrypt_file
    encrypt_file(args.recipient, args.file)


def cmd_decrypt(args):
    from decrypt import decrypt_file
    out = args.output or None
    decrypt_file(args.identity, args.file, out)


def cmd_revoke(args):
    from keygen import revoke_certificate
    revoke_certificate(args.identity)


def cmd_validate(args):
    from keygen import validate_certificate
    ok = validate_certificate(args.identity)
    sys.exit(0 if ok else 1)


def cmd_pkcs12(args):
    from keygen import export_pkcs12
    export_pkcs12(args.identity, args.password)


def cmd_demo(args):
    """Run a full end-to-end demonstration."""
    import os
    from keygen import generate_rsa_keypair, revoke_certificate, validate_certificate
    from sign import sign_file, sign_message
    from verify import verify_file, verify_message
    from encrypt import encrypt_file, encrypt_message
    from decrypt import decrypt_file, decrypt_message

    print("\n" + "=" * 60)
    print("  PKI CRYPTOGRAPHIC TOOL — LIVE DEMO")
    print("=" * 60)

    # Setup
    print("\n[STEP 1] Generate key pairs for Alice and Bob")
    generate_rsa_keypair("alice")
    generate_rsa_keypair("bob")

    print("\n[STEP 2] Alice signs a contract")
    with open("demo_contract.txt", "w") as f:
        f.write("Service Agreement: Alice will deliver the project by June 2026.")
    meta = sign_file("alice", "demo_contract.txt")

    print("\n[STEP 3] Bob verifies Alice's signature")
    verify_file(meta, skip_replay_check=True)

    print("\n[STEP 4] Bob encrypts a reply for Alice")
    blob = encrypt_message("alice", "Alice, contract received and approved. - Bob")
    msg = decrypt_message("alice", blob)

    print("\n[STEP 5] Replay attack simulation")
    signed = sign_message("alice", "Pay Bob $1000")
    print("  First verification (should PASS):")
    verify_message(signed, skip_replay_check=False)
    print("  Second verification (should FAIL — replay attack):")
    verify_message(signed, skip_replay_check=False)

    print("\n[STEP 6] Certificate revocation")
    revoke_certificate("alice")
    validate_certificate("alice")

    print("\n[STEP 7] File encryption roundtrip")
    with open("secret_doc.txt", "w") as f:
        f.write("TOP SECRET: Nuclear launch codes = 000000")
    encrypt_file("bob", "secret_doc.txt")
    decrypt_file("bob", "secret_doc.txt.enc", "secret_doc_recovered.txt")
    print("  Roundtrip OK:", open("secret_doc_recovered.txt").read())

    print("\n" + "=" * 60)
    print("  DEMO COMPLETE")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(
        description="PKI Cryptographic Tool — ST6051CEM Coursework",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # keygen
    p = sub.add_parser("keygen", help="Generate RSA key pair + certificate")
    p.add_argument("identity", help="Identity label (e.g. alice)")
    p.set_defaults(func=cmd_keygen)

    # sign
    p = sub.add_parser("sign", help="Sign a file")
    p.add_argument("identity", help="Signer identity")
    p.add_argument("file", help="File to sign")
    p.set_defaults(func=cmd_sign)

    # verify
    p = sub.add_parser("verify", help="Verify a file signature")
    p.add_argument("meta", help="Path to .meta.json file")
    p.add_argument("--no-replay", action="store_true", help="Skip replay/timestamp checks (for testing)")
    p.set_defaults(func=cmd_verify)

    # encrypt
    p = sub.add_parser("encrypt", help="Encrypt a file for a recipient")
    p.add_argument("recipient", help="Recipient identity")
    p.add_argument("file", help="File to encrypt")
    p.set_defaults(func=cmd_encrypt)

    # decrypt
    p = sub.add_parser("decrypt", help="Decrypt a file")
    p.add_argument("identity", help="Recipient identity (private key holder)")
    p.add_argument("file", help="Encrypted .enc file")
    p.add_argument("--output", "-o", help="Output file path")
    p.set_defaults(func=cmd_decrypt)

    # revoke
    p = sub.add_parser("revoke", help="Revoke a certificate")
    p.add_argument("identity", help="Identity to revoke")
    p.set_defaults(func=cmd_revoke)

    # validate
    p = sub.add_parser("validate", help="Validate a certificate")
    p.add_argument("identity", help="Identity to validate")
    p.set_defaults(func=cmd_validate)

    # pkcs12
    p = sub.add_parser("pkcs12", help="Export PKCS#12 password-protected keystore")
    p.add_argument("identity", help="Identity")
    p.add_argument("password", help="Keystore password")
    p.set_defaults(func=cmd_pkcs12)

    # demo
    p = sub.add_parser("demo", help="Run full end-to-end demonstration")
    p.set_defaults(func=cmd_demo)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
