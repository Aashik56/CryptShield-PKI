# -*- coding: utf-8 -*-
"""
tests/test_cryptotool.py - Comprehensive Test Suite
PKI Cryptographic Tool | ST6051CEM Coursework

Tests:
- Key generation and certificate management
- Digital signing and verification
- Hybrid encryption/decryption
- Attack simulations:
    * Tampered file detection
    * Wrong recipient decryption attempt
    * Replay attack detection
    * Revoked certificate rejection
    * Unauthorized signer rejection
"""

import os
import sys
import json
import shutil
import tempfile
import unittest
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from keygen import generate_rsa_keypair, revoke_certificate, is_revoked, validate_certificate, export_pkcs12
from sign import sign_file, sign_message
from verify import verify_file, verify_message
from encrypt import encrypt_file, encrypt_message
from decrypt import decrypt_file, decrypt_message


class TestKeyGeneration(unittest.TestCase):

    def setUp(self):
        """Set up a temporary working directory."""
        self.orig_dir = os.getcwd()
        self.tmpdir = tempfile.mkdtemp()
        os.chdir(self.tmpdir)

    def tearDown(self):
        os.chdir(self.orig_dir)
        shutil.rmtree(self.tmpdir)

    def test_rsa_keypair_generation(self):
        """Keys and certificate files should be created."""
        result = generate_rsa_keypair("testuser")
        self.assertTrue(Path(result["private_key"]).exists())
        self.assertTrue(Path(result["public_key"]).exists())
        self.assertTrue(Path(result["certificate"]).exists())

    def test_pkcs12_export(self):
        """PKCS#12 keystore should be created."""
        generate_rsa_keypair("testuser")
        p12_path = export_pkcs12("testuser", "TestPass123!")
        self.assertTrue(Path(p12_path).exists())

    def test_certificate_validation(self):
        """A freshly generated certificate should be valid."""
        generate_rsa_keypair("testuser")
        self.assertTrue(validate_certificate("testuser"))

    def test_certificate_revocation(self):
        """A revoked certificate should fail validation."""
        generate_rsa_keypair("testuser")
        revoke_certificate("testuser")
        self.assertTrue(is_revoked("testuser"))
        self.assertFalse(validate_certificate("testuser"))


class TestDigitalSignatures(unittest.TestCase):

    def setUp(self):
        self.orig_dir = os.getcwd()
        self.tmpdir = tempfile.mkdtemp()
        os.chdir(self.tmpdir)
        generate_rsa_keypair("alice")
        generate_rsa_keypair("mallory")
        self.test_file = Path("document.txt")
        self.test_file.write_text("This is an important document.")

    def tearDown(self):
        os.chdir(self.orig_dir)
        shutil.rmtree(self.tmpdir)

    def test_valid_signature(self):
        """A correctly signed file should verify successfully."""
        meta = sign_file("alice", str(self.test_file))
        self.assertTrue(verify_file(meta, skip_replay_check=True))

    def test_tampered_file_detected(self):
        """Tampered file should fail signature verification."""
        meta = sign_file("alice", str(self.test_file))
        # Tamper with the file after signing
        self.test_file.write_text("TAMPERED content — different from original.")
        self.assertFalse(verify_file(meta, skip_replay_check=True))

    def test_unauthorized_signer_rejected(self):
        """Signature by wrong party should not verify using alice's public key."""
        # Mallory signs, but metadata says alice — simulate MITM key swap
        mallory_meta = sign_file("mallory", str(self.test_file))

        # Tamper metadata to claim alice signed
        with open(mallory_meta) as f:
            meta = json.load(f)
        meta["signer"] = "alice"
        with open(mallory_meta, "w") as f:
            json.dump(meta, f)

        # Should fail — alice's key can't verify mallory's signature
        self.assertFalse(verify_file(mallory_meta, skip_replay_check=True))

    def test_revoked_cert_rejected(self):
        """Signature from a revoked identity should be rejected."""
        meta = sign_file("alice", str(self.test_file))
        revoke_certificate("alice")
        self.assertFalse(verify_file(meta, skip_replay_check=True))

    def test_replay_attack_detection(self):
        """Second use of the same nonce should be rejected."""
        signed = sign_message("alice", "Pay Bob $100")
        # First verification: should succeed
        result1 = verify_message(signed, skip_replay_check=False)
        # Second verification with same nonce (replay): should fail
        result2 = verify_message(signed, skip_replay_check=False)
        # One of these will succeed, other will fail — both can't be True
        # Actually first should succeed, second should fail
        self.assertTrue(result1)
        self.assertFalse(result2)

    def test_message_signature(self):
        """Signed messages should verify correctly."""
        signed = sign_message("alice", "Authorize payment of $500")
        self.assertTrue(verify_message(signed, skip_replay_check=True))


class TestEncryptionDecryption(unittest.TestCase):

    def setUp(self):
        self.orig_dir = os.getcwd()
        self.tmpdir = tempfile.mkdtemp()
        os.chdir(self.tmpdir)
        generate_rsa_keypair("bob")
        generate_rsa_keypair("eve")
        self.test_file = Path("plaintext.txt")
        self.test_file.write_text("Confidential: Project Alpha launch date is 2026-04-01.")

    def tearDown(self):
        os.chdir(self.orig_dir)
        shutil.rmtree(self.tmpdir)

    def test_encrypt_decrypt_roundtrip(self):
        """Encrypting then decrypting a file should restore original content."""
        enc_path = encrypt_file("bob", str(self.test_file))
        dec_path = decrypt_file("bob", enc_path, "decrypted.txt")
        original = self.test_file.read_text()
        recovered = Path(dec_path).read_text()
        self.assertEqual(original, recovered)

    def test_wrong_recipient_rejected(self):
        """Eve cannot decrypt a file encrypted for Bob."""
        enc_path = encrypt_file("bob", str(self.test_file))
        with self.assertRaises(Exception):
            decrypt_file("eve", enc_path, "eve_attempt.txt")

    def test_tampered_ciphertext_rejected(self):
        """Tampered ciphertext should fail GCM authentication."""
        enc_path = encrypt_file("bob", str(self.test_file))
        # Flip bytes in ciphertext section
        with open(enc_path, "rb") as f:
            data = bytearray(f.read())
        # Tamper near end (ciphertext + tag area)
        data[-20] ^= 0xFF
        data[-10] ^= 0xAA
        with open(enc_path, "wb") as f:
            f.write(data)
        from cryptography.exceptions import InvalidTag
        with self.assertRaises(InvalidTag):
            decrypt_file("bob", enc_path, "tampered_dec.txt")

    def test_message_encrypt_decrypt(self):
        """Encrypted messages should decrypt correctly."""
        blob = encrypt_message("bob", "Secret coordinates: 27.7N, 85.3E")
        result = decrypt_message("bob", blob)
        self.assertEqual(result, "Secret coordinates: 27.7N, 85.3E")

    def test_different_ciphertext_each_time(self):
        """Encryption should produce different ciphertext each time (IND-CPA)."""
        blob1 = encrypt_message("bob", "Same message")
        blob2 = encrypt_message("bob", "Same message")
        self.assertNotEqual(blob1, blob2)  # Random IV/key ensures uniqueness


class TestMultiUserWorkflow(unittest.TestCase):
    """
    Simulate a real-world workflow:
    Alice signs a contract, Bob and Charlie verify it.
    Mallory tries to forge Alice's signature.
    """

    def setUp(self):
        self.orig_dir = os.getcwd()
        self.tmpdir = tempfile.mkdtemp()
        os.chdir(self.tmpdir)
        for user in ["alice", "bob", "charlie", "mallory"]:
            generate_rsa_keypair(user)
        self.contract = Path("contract.txt")
        self.contract.write_text("Contract: Alice agrees to deliver software by 2026-06-01.")

    def tearDown(self):
        os.chdir(self.orig_dir)
        shutil.rmtree(self.tmpdir)

    def test_multi_user_signing_and_verification(self):
        """Alice signs; Bob and Charlie can both verify."""
        meta = sign_file("alice", str(self.contract))
        self.assertTrue(verify_file(meta, skip_replay_check=True))  # Bob verifies
        self.assertTrue(verify_file(meta, skip_replay_check=True))  # Charlie verifies

    def test_mallory_forgery_rejected(self):
        """Mallory signs with her key but claims to be Alice — should fail."""
        meta_path = sign_file("mallory", str(self.contract))

        # Tampering: change signer field to "alice"
        with open(meta_path) as f:
            meta = json.load(f)
        meta["signer"] = "alice"
        with open(meta_path, "w") as f:
            json.dump(meta, f)

        self.assertFalse(verify_file(meta_path, skip_replay_check=True))

    def test_secure_message_between_users(self):
        """Alice encrypts a message for Bob; only Bob can read it; Charlie cannot."""
        blob = encrypt_message("bob", "Bob, here is the secret key: XK9-ALPHA")
        # Bob decrypts successfully
        msg = decrypt_message("bob", blob)
        self.assertIn("XK9-ALPHA", msg)
        # Charlie cannot decrypt
        with self.assertRaises(Exception):
            decrypt_message("charlie", blob)


if __name__ == "__main__":
    print("=" * 60)
    print("PKI Cryptographic Tool — Full Test Suite")
    print("=" * 60)
    unittest.main(verbosity=2)
